/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectojdbc;

/**
 *
 * @author Lenovo
 */
public class ProyectoJDBC {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
